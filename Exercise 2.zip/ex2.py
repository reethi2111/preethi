def countX(lst,x):
    c=0
    for i in range(len(lst)):
        if (x==lst[i]):
            c=c+1
    return c
lst=[]
n=int(input())
for _ in range(n):
    lst.append(int(input()))
x=int(input())
occ=countX(lst,x)
print(occ)