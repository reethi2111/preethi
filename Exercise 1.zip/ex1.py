import calendar 
year=int(input())
month=int(input())
if((year>999 and year<10000) and (month>=1 and month<=12)):
    print(calendar.month(year,month))
else:
    print("invalid input")
        