def convert(s):
    new=""
    for x in s:
        new+=x
    return new 
a=input()
b=input()
s1=a.strip()
s2=b.strip()
if(len(s1)>=2 and len(s2)>=2):
    t1 = list(s1)
    t2=list(s2)
    c1 = t1[0]
    c2 = t1[1]
    t1[0]=t2[0]
    t1[1]=t2[1]
    t2[0]=c1
    t2[1]=c2
    s1=convert(t1)
    s2=convert(t2)
    print(s1,"",s2)
else:
    print("invalid")
            
                